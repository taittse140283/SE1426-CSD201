import os
idd = "SE141094"

exec_strs = [
    "java -jar "+ idd +".jar 1 -r testcase.csv -s out1_0.csv",
    "java -jar "+ idd +".jar 1 -r testcase.csv -g inbimfgw@gmail.com > out1_1.csv",
    "java -jar "+ idd +".jar 1 -r testcase.csv -s out1_2.csv -a ack@gmail.com 979517",
    "java -jar "+ idd +".jar 1 -r testcase.csv -s out1_3.csv -d rpxgg@gmail.com",
    "java -jar "+ idd +".jar 1 -r testcase.csv -s out1_4.csv -u jgsornk@gmail.com 999999",
    "java -jar "+ idd +".jar 1 -r testcase.csv -s out1_5.csv -dt",
    "java -jar "+ idd +".jar 1 -r testcase.csv -t > out1_6.csv",
    "java -jar "+ idd +".jar -h > out1_7.csv",
    "java -jar "+ idd +".jar 2 https://www.journaldev.com/629/java-catch-multiple-exceptions-rethrow-exception out1_8.csv",
    "java -jar "+ idd +".jar 2 https://autotouch.net out1_9.csv",
    "java -jar "+ idd +".jar 2 https://www.w3schools.com out1_10.csv",
    "java -jar "+ idd +".jar 2 https://www.wikipedia.org out1_11.csv"
]

your_point = 0
for index, exec_str in enumerate(exec_strs):
    print(exec_strs[index])
    os.system(exec_str)
    with open("out1_" + str(index) + ".csv") as output:
        content = output.readlines()
        if index == 0:
            try:
                with open("lab1_" + str(index) + ".csv") as basefile:
                    base_content = basefile.readlines()
                    flag = True
                    for i, line in enumerate(base_content):
                        base_rows = line.strip().split(",")
                        rows = content[i].strip().split(",")
                        if base_rows[0].strip().upper() != rows[0].strip().upper() or base_rows[1].strip().upper() != rows[1].strip().upper():
                            flag = False
                    if flag:
                        your_point += 0.5
                        print("Your answer is correct")
                        print("Your points = " + str(your_point))
                    else:
                        print("Your answer is not correct")
                        print("Your points = " + str(your_point))
            except:
                    print("Your answer has an error")
                    print("Your points = " + str(your_point))                    
        elif index == 1:
            with open("lab1_" + str(index) + ".csv") as basefile:
                base_content = basefile.readlines()
                try:
                    point = int(content[0])
                    base_point = int(base_content[0])
                    if point == base_point:
                        your_point += 0.5
                        print("Your answer is correct")
                        print("Your points = " + str(your_point))
                    else:
                        print("Your answer is not correct")
                        print("Your points = " + str(your_point))
                except:
                    print("Your answer has an error")
                    print("Your points = " + str(your_point))
        elif index == 2:
            try:
                with open("lab1_" + str(index) + ".csv") as basefile:
                    base_content = basefile.readlines()
                    flag = True
                    for i, line in enumerate(base_content):
                        base_rows = line.strip().split(",")
                        rows = content[i].strip().split(",")
                        if base_rows[0].strip().upper() != rows[0].strip().upper() or base_rows[1].strip().upper() != rows[1].strip().upper():
                            flag = False
                            break
                    if flag:
                        your_point += 0.5
                        print("Your answer is correct")
                        print("Your points = " + str(your_point))
                    else:
                        print("Your answer is not correct")
                        print("Your points = " + str(your_point))
            except:
                    print("Your answer has an error")
                    print("Your points = " + str(your_point))    
        elif index == 3:
            try:
                with open("lab1_" + str(index) + ".csv") as basefile:
                    base_content = basefile.readlines()
                    flag = True
                    for i, line in enumerate(base_content):
                        base_rows = line.strip().split(",")
                        rows = content[i].strip().split(",")
                        if base_rows[0].strip().upper() != rows[0].strip().upper() or base_rows[1].strip().upper() != rows[1].strip().upper():
                            flag = False
                            break
                    if flag:
                        your_point += 0.5
                        print("Your answer is correct")
                        print("Your points = " + str(your_point))
                    else:
                        print("Your answer is not correct")
                        print("Your points = " + str(your_point))
            except:
                    print("Your answer has an error")
                    print("Your points = " + str(your_point))
        elif index == 4:
            try:
                with open("lab1_" + str(index) + ".csv") as basefile:
                    base_content = basefile.readlines()
                    flag = True
                    for i, line in enumerate(base_content):
                        base_rows = line.strip().split(",")
                        rows = content[i].strip().split(",")
                        if base_rows[0].strip().upper() != rows[0].strip().upper() or base_rows[1].strip().upper() != rows[1].strip().upper():
                            flag = False
                            break
                    if flag:
                        your_point += 0.5
                        print("Your answer is correct")
                        print("Your points = " + str(your_point))
                    else:
                        print("Your answer is not correct")
                        print("Your points = " + str(your_point))
            except:
                    print("Your answer has an error")
                    print("Your points = " + str(your_point))
        elif index == 5:
            try:
                with open("lab1_" + str(index) + ".csv") as basefile:
                    base_content = basefile.readlines()
                    flag = True
                    for i, line in enumerate(base_content):
                        base_rows = line.strip().split(",")
                        rows = content[i].strip().split(",")
                        if base_rows[0].strip().upper() != rows[0].strip().upper() or base_rows[1].strip().upper() != rows[1].strip().upper():
                            flag = False
                            break
                    if flag:
                        your_point += 0.5
                        print("Your answer is correct")
                        print("Your points = " + str(your_point))
                    else:
                        print("Your answer is not correct")
                        print("Your points = " + str(your_point))
            except:
                    print("Your answer has an error")
                    print("Your points = " + str(your_point))
        elif index == 6:
            with open("lab1_" + str(index) + ".csv") as basefile:
                base_content = basefile.readlines()
                try:
                    point = int(content[0])
                    base_point = int(base_content[0])
                    if point == base_point:
                        your_point += 0.5
                        print("Your answer is correct")
                        print("Your points = " + str(your_point))
                    else:
                        print("Your answer is not correct")
                        print("Your points = " + str(your_point))
                except:
                    print("Your answer has an error")
                    print("Your points = " + str(your_point))
        elif index == 7:
            try:
                if "Help" in content[0] or "help" in content[0]:
                    your_point += 0.5
                    print("Your answer is correct")
                    print("Your points = " + str(your_point))
                else:
                    print("Your answer is not correct")
                    print("Your points = " + str(your_point))
            except:
                print("Your answer has an error")
                print("Your points = " + str(your_point))
        elif index > 7:
            try:
                dic = {}
                with open("lab1_" + str(index) + ".csv") as basefile:
                    base_content = basefile.readlines()
                    flag = True
                    for i, line in enumerate(base_content):
                        base_rows = line.strip().split(",")
                        dic[base_rows[0].strip().upper()] = base_rows[1].strip().upper()
                    for i, line in enumerate(content):
                        rows = line.strip().split(",")
                        value = dic.get(rows[0].strip().upper(), "Error")
                        if value != rows[1].strip().upper():
                            flag = False
                            break
                    if flag:
                        your_point += 1.0
                        print("Your answer is correct")
                        print("Your points = " + str(your_point))
                    else:
                        print("Your answer is not correct")
                        print("Your points = " + str(your_point))
            except:
                    print("Your answer has an error")
                    print("Your points = " + str(your_point))
